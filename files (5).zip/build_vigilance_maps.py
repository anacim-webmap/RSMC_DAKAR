#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_vigilance_maps.py
========================

Pipeline de production des cartes de vigilance SWFDP (Afrique de l'Ouest).

Ce script :
  1. Lit les 5 fichiers .gpkg fusionnés (un par échéance : J1 à J5), qui
     contiennent déjà les polygones de vigilance fusionnés avec leurs
     attributs (Phenomene, Seuil_code, Seuil_val, Couleur_ph, etc.).
  2. Harmonise les attributs de chaque entité pour qu'ils utilisent
     exactement les mêmes champs / noms de champs, avec le nom complet
     de chaque phénomène (ex: "G: Vent", "Hs: Houle", "RR: Pluie",
     "T: Température") tel que fourni dans les .gpkg :
         fid, id, Phenomene, Seuil_code, Seuil_val, Unite, Echeance,
         Date_début, Date_fin, Couleur_ph, Commentair, layer, path
  3. Garantit que la couleur (Couleur_ph) est toujours la même pour un
     même couple (Phenomene, Seuil_val), même si une des tables sources
     contient une couleur incohérente : une palette de référence est
     construite automatiquement à partir de l'ensemble des 5 fichiers
     (vote majoritaire), puis appliquée à toutes les entités.
  3bis. Calcule automatiquement Date_début et Date_fin pour chaque
     échéance à partir d'une date de base (Jour-J = J1) :
         J1 : date_base        -> date_base + 1 jour
         J2 : date_base + 1j   -> date_base + 2 jours
         J3 : date_base + 2j   -> date_base + 3 jours
         J4 : date_base + 3j   -> date_base + 4 jours
         J5 : date_base + 4j   -> date_base + 5 jours
     La date de base vaut par défaut la date du jour d'exécution du
     script, et peut être fixée avec --date-base AAAA-MM-JJ.
  4. Réécrit, pour chaque jour, un GeoPackage propre et homogène
     (carte_jour_X.gpkg) -> utile si vous rechargez ces fichiers dans QGIS.
  5. Exporte un GeoJSON valide (carte_jour_X.geojson) pour chaque jour.
  6. Génère le fichier JavaScript correspondant (carte_jour_X.js), au
     format `var carte_jour_X = { ...GeoJSON... };`, directement
     compatible avec les balises <script src="carte_jour_X.js"> de
     carte_vigilance_final.html.

Utilisation
-----------
    python3 build_vigilance_maps.py --input-dir /chemin/vers/gpkg \
                                     --output-dir /chemin/vers/sortie

Par défaut, --input-dir et --output-dir valent le répertoire courant.

Dépendances : geopandas, fiona, shapely (pip install geopandas fiona shapely)
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path

import fiona
import geopandas as gpd

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------

JOURS = [1, 2, 3, 4, 5]

# Champs finaux, dans cet ordre, pour coller au format déjà utilisé par
# les fichiers carte_jour_X.js consommés par le HTML.
CHAMPS_FINAUX = [
    "fid", "id", "Phenomene", "Seuil_code", "Seuil_val", "Unite",
    "Echeance", "Date_début", "Date_fin", "Couleur_ph", "Commentair",
    "layer", "path",
]

# Si un .gpkg contient plusieurs couches, ordre de préférence des noms
# de couches à utiliser (la plus complète / la plus récente d'abord).
PREFERENCE_COUCHES = {
    1: ["carte_jour_1", "carte_jour1"],
}


def nom_fichier_gpkg(jour: int) -> str:
    return f"carte_jour_{jour}.gpkg"


def choisir_couche(chemin_gpkg: Path, jour: int) -> str:
    """Choisit la couche à utiliser dans un .gpkg pouvant contenir plusieurs couches."""
    couches = fiona.listlayers(str(chemin_gpkg))
    preferences = PREFERENCE_COUCHES.get(jour, [])
    for nom in preferences:
        if nom in couches:
            return nom
    # Sinon, on prend la première couche disponible.
    return couches[0]


def phenomene_court(valeur: str) -> str:
    """'G: Vent' -> 'G' ; 'Hs: Houle' -> 'Hs' ; laisse tel quel si pas de ':'."""
    if not valeur:
        return valeur
    return valeur.split(":")[0].strip()


def calculer_dates_echeance(jour: int, date_base: date) -> tuple:
    """
    Calcule automatiquement la date de début et la date de fin de validité
    d'une échéance, à partir d'une date de base (= Jour-J, date d'émission
    du bulletin, correspondant à J1) :

        J1 : Date_début = date_base           Date_fin = date_base + 1 jour
        J2 : Date_début = date_base + 1 jour   Date_fin = date_base + 2 jours
        J3 : Date_début = date_base + 2 jours  Date_fin = date_base + 3 jours
        J4 : Date_début = date_base + 3 jours  Date_fin = date_base + 4 jours
        J5 : Date_début = date_base + 4 jours  Date_fin = date_base + 5 jours

    Renvoie (Date_début, Date_fin) au format 'YYYY-MM-DD'.
    """
    debut = date_base + timedelta(days=jour - 1)
    fin = date_base + timedelta(days=jour)
    return debut.isoformat(), fin.isoformat()


def charger_gdf(chemin_gpkg: Path, jour: int) -> gpd.GeoDataFrame:
    couche = choisir_couche(chemin_gpkg, jour)
    gdf = gpd.read_file(chemin_gpkg, layer=couche)
    if gdf.crs is None:
        gdf.set_crs(epsg=4326, inplace=True)
    else:
        gdf = gdf.to_crs(epsg=4326)
    return gdf


def construire_palette_reference(gdfs_par_jour: dict) -> dict:
    """
    Construit un dictionnaire {(Phenomene_court, Seuil_val): Couleur_ph}
    en votant à la majorité sur les 5 fichiers, pour garantir un code
    couleur unique et cohérent par phénomène/seuil, quel que soit le jour.
    """
    votes = defaultdict(Counter)
    for jour, gdf in gdfs_par_jour.items():
        for _, row in gdf.iterrows():
            phen = phenomene_court(row.get("Phenomene"))
            seuil = row.get("Seuil_val")
            couleur = row.get("Couleur_ph")
            if phen is not None and seuil is not None and couleur:
                votes[(phen, float(seuil))][couleur] += 1

    palette = {cle: compteur.most_common(1)[0][0] for cle, compteur in votes.items()}
    return palette


def harmoniser_gdf(gdf: gpd.GeoDataFrame, jour: int, palette: dict, date_base: date) -> gpd.GeoDataFrame:
    """Reconstruit un GeoDataFrame avec exactement les champs CHAMPS_FINAUX."""
    date_debut, date_fin = calculer_dates_echeance(jour, date_base)

    lignes = []
    for i, row in enumerate(gdf.itertuples(index=False), start=1):
        d = row._asdict()
        # Nom complet du phénomène tel que fourni dans le .gpkg
        # (ex: "G: Vent", "Hs: Houle", "RR: Pluie", "T: Température").
        phen_complet = d.get("Phenomene")
        # Code court utilisé uniquement pour regrouper les couleurs par
        # phénomène/seuil (la palette de référence est indexée dessus).
        phen_court = phenomene_court(phen_complet)
        seuil_val = d.get("Seuil_val")
        cle_couleur = (phen_court, float(seuil_val)) if seuil_val is not None else None

        couleur = palette.get(cle_couleur, d.get("Couleur_ph"))

        lignes.append({
            "fid": i,
            "id": d.get("id"),
            "Phenomene": phen_complet,
            "Seuil_code": d.get("Seuil_code"),
            "Seuil_val": seuil_val,
            "Unite": d.get("Unite"),
            "Echeance": d.get("Echeance") or f"J{jour}",
            "Date_début": date_debut,
            "Date_fin": date_fin,
            "Couleur_ph": couleur,
            "Commentair": d.get("Commentair"),
            "layer": d.get("layer"),
            "path": d.get("path"),
            "geometry": d.get("geometry"),
        })

    gdf_final = gpd.GeoDataFrame(lignes, geometry="geometry", crs="EPSG:4326")
    gdf_final = gdf_final[CHAMPS_FINAUX + ["geometry"]]
    return gdf_final


def ecrire_gpkg(gdf: gpd.GeoDataFrame, chemin_sortie: Path, jour: int):
    couche = f"carte_jour_{jour}"
    # Si le fichier de sortie existe déjà (ex: on écrit dans le même dossier
    # que les .gpkg sources), on le supprime d'abord pour repartir d'un
    # GeoPackage propre. Sans cela, GDAL peut refuser de recréer une couche
    # de même nom (y compris avec une casse différente, ex: 'Carte_jour_2'
    # vs 'carte_jour_2') et lever une erreur "Layer already exists".
    if chemin_sortie.exists():
        chemin_sortie.unlink()
    gdf.to_file(chemin_sortie, layer=couche, driver="GPKG")


def geojson_dict_depuis_gdf(gdf: gpd.GeoDataFrame, jour: int) -> dict:
    """Construit un dict GeoJSON propre (FeatureCollection) à partir du GeoDataFrame."""
    brut = json.loads(gdf.to_json())
    fc = {
        "type": "FeatureCollection",
        "name": f"carte_jour_{jour}",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
        "features": brut["features"],
    }
    return fc


def ecrire_geojson(fc: dict, chemin_sortie: Path):
    with open(chemin_sortie, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False, indent=None, separators=(", ", ": "))


def ecrire_js(fc: dict, chemin_sortie: Path, jour: int):
    contenu_json = json.dumps(fc, ensure_ascii=False, separators=(", ", ": "))
    with open(chemin_sortie, "w", encoding="utf-8") as f:
        f.write(f"var carte_jour_{jour} =\n{contenu_json}\n;\n")


def main():
    parser = argparse.ArgumentParser(description="Pipeline .gpkg -> .geojson -> .js pour la carte de vigilance.")
    parser.add_argument("--input-dir", type=Path, default=Path("."),
                         help="Répertoire contenant carte_jour_1.gpkg ... carte_jour_5.gpkg")
    parser.add_argument("--output-dir", type=Path, default=Path("."),
                         help="Répertoire de sortie pour les .gpkg / .geojson / .js régénérés")
    parser.add_argument("--date-base", type=str, default=None,
                         help="Date de base (Jour-J, correspondant à J1) au format YYYY-MM-DD. "
                              "Par défaut : date du jour d'exécution du script. "
                              "J2 = date_base+1j, J3 = +2j, J4 = +3j, J5 = +4j "
                              "(mise à jour automatique, aucune saisie manuelle nécessaire).")
    args = parser.parse_args()

    if args.date_base:
        date_base = date.fromisoformat(args.date_base)
    else:
        date_base = date.today()
    print(f"Date de base (J1) utilisée pour Date_début/Date_fin : {date_base.isoformat()}")

    args.output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Chargement de tous les jours
    gdfs = {}
    for jour in JOURS:
        chemin = args.input_dir / nom_fichier_gpkg(jour)
        if not chemin.exists():
            print(f"[ATTENTION] {chemin} introuvable, jour {jour} ignoré.", file=sys.stderr)
            continue
        gdfs[jour] = charger_gdf(chemin, jour)
        print(f"[OK] {chemin.name} chargé : {len(gdfs[jour])} entités (couche '{choisir_couche(chemin, jour)}').")

    if not gdfs:
        print("Aucun fichier .gpkg trouvé, arrêt.", file=sys.stderr)
        sys.exit(1)

    # 2. Palette de référence Couleur_ph par (Phenomene, Seuil_val)
    palette = construire_palette_reference(gdfs)
    print("\nPalette de couleurs de référence (Phenomene, Seuil_val) -> Couleur_ph :")
    for cle, couleur in sorted(palette.items(), key=lambda x: (x[0][0], x[0][1])):
        print(f"   {cle[0]:>3} > {cle[1]:<6} -> {couleur}")

    # 3. Harmonisation + écriture des sorties pour chaque jour
    for jour, gdf in gdfs.items():
        gdf_final = harmoniser_gdf(gdf, jour, palette, date_base)

        chemin_gpkg = args.output_dir / f"carte_jour_{jour}.gpkg"
        chemin_geojson = args.output_dir / f"carte_jour_{jour}.geojson"
        chemin_js = args.output_dir / f"carte_jour_{jour}.js"

        ecrire_gpkg(gdf_final, chemin_gpkg, jour)
        fc = geojson_dict_depuis_gdf(gdf_final, jour)
        ecrire_geojson(fc, chemin_geojson)
        ecrire_js(fc, chemin_js, jour)

        print(f"\n[JOUR {jour}] {len(gdf_final)} entités écrites -> "
              f"{chemin_gpkg.name}, {chemin_geojson.name}, {chemin_js.name}")

    print("\nTerminé. Copiez les fichiers carte_jour_1.js ... carte_jour_5.js "
          "à côté de carte_vigilance_final.html pour mettre la carte à jour.")


if __name__ == "__main__":
    main()
